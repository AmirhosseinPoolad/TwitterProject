package main.java.org.ce.ap.server.jsonHandling.impl.result;

import main.java.org.ce.ap.server.jsonHandling.Result;

public class EmptyResult extends Result {
}
