package main.java.org.ce.ap.server.services;

public interface PropertiesService {
    String getProperty(String name);
}
