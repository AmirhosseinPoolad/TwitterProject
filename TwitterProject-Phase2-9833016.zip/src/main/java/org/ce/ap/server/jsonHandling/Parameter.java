package main.java.org.ce.ap.server.jsonHandling;

public abstract class Parameter {
}
