package main.java.org.ce.ap.server.services;

public interface LoggingService {
    public  void log(String logString);
}
